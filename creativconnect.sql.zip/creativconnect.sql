-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 06, 2013 at 12:49 PM
-- Server version: 5.1.44
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `creativconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `business`
--

CREATE TABLE IF NOT EXISTS `business` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `businessname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `website` varchar(50) NOT NULL,
  `industry` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `status` varchar(11) NOT NULL,
  `location` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `business`
--


-- --------------------------------------------------------

--
-- Table structure for table `freeusers`
--

CREATE TABLE IF NOT EXISTS `freeusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `website` varchar(50) NOT NULL,
  `industry` varchar(255) NOT NULL,
  `bio` text NOT NULL,
  `status` varchar(11) NOT NULL,
  `location` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `freeusers`
--

INSERT INTO `freeusers` (`id`, `username`, `firstname`, `lastname`, `email`, `password`, `website`, `industry`, `bio`, `status`, `location`, `photo`) VALUES
(0, 'kanvazkid', 'Asim', 'Craft', 'vectornpixel@gmail.com', 'a1f374bffe53c105e24adb638c78cd52', 'www.vectornpixel.com', 'Graphic Designer', 'this is a test bio', 'open', 'Detroit', ''),
(16, 'johndoe', 'John', 'Doe', 'ballinice@hotmail.com', 'a1f374bffe53c105e24adb638c78cd52', '', 'Graphic Designer', '', '', '0', ''),
(79, 'heyyo', 'hey', 'yo', 'vectornpixel@gmail.com', 'a1f374bffe53c105e24adb638c78cd52', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE IF NOT EXISTS `portfolio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `category` varchar(50) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `username`, `category`, `filename`) VALUES
(64, 'kanvazkid', 'Logo Design', 'teenage_mutant_ninja_turtles_out_of_the_shadows_game-wide.jpg'),
(63, 'kanvazkid', 'Web Design', 'Destroyed-Wall-stock6665.jpg'),
(62, 'johndoe', '0', 'Central-Cafe-stock6619.jpg'),
(61, 'kanvazkid', '0', 'creative_fantasy_girl-wide.jpg'),
(60, 'kanvazkid', '0', 'stage_curtain_spotlight.jpg'),
(59, 'kanvazkid', '0', '---Tokyo-stock6581.jpg'),
(58, 'kanvazkid', '0', 'curtains3.jpg'),
(57, 'kanvazkid', '0', 'curtains2.jpg'),
(52, '0', '0', 'curtains.jpg'),
(56, 'kanvazkid', '0', 'curtains1.jpg'),
(55, 'kanvazkid', '0', 'curtains.jpg'),
(54, 'kanvazkid', '0', 'creative_fantasy_girl-wide.jpg'),
(53, 'kanvazkid', '0', 'Destroyed-Wall-stock6665.jpg'),
(51, '0', '0', 'demon_alien_devil_skull-wide.jpg');
